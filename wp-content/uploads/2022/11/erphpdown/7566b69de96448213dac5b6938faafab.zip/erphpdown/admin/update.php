<?php 
if(versioncheck() > $erphpdown_version*100)
	{?>
		<br /><br />有更新可下载，<a href="http://www.mobantu.com/1780.html" target="_blank">去下载更新</a>。
	<?php }else{?>
		<br /><br />无更新可下载。
	<?php }?>
	<br /><br /><br />
	官方网站：http://www.mobantu.com &nbsp;&nbsp;http://erphpdown.com
